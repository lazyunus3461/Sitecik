# VALI DIECAST

Mevcut siyah/altın tasarımı koruyan, sunuculu mağaza ve koleksiyon platformu. Kredi kartı, ödeme sağlayıcısı veya kullanıcıların kendi kendine bakiye yüklemesi yoktur.

## Çalıştırma

Node.js 24.x gerekir. Ek paket kurulumu gerekmez.

```bash
npm start
```

İlk çalıştırmada `admin` hesabı oluşturulur. Güçlü, rastgele şifresi sunucu terminalinde yalnızca bir kez gösterilir. İstersen ilk çalıştırmadan önce `VD_ADMIN_PASSWORD` ortam değişkeniyle en az 12 karakterlik kendi şifreni belirle. `admin/admin` girişi yoktur.

Site yerelde `http://localhost:3000` adresinde açılır. Kalıcı kayıtlar `data/vali.sqlite`, kullanıcı fotoğrafları `data/media` altında tutulur. Sunucuda bu dizine kalıcı disk bağla; geçici disk kullanma.

## Yayına alma

Node.js çalıştırabilen hosting veya bir sunucuya bu klasörün tamamını yükle. HTTPS alan adını uygulamaya yönlendir. Ortam değişkenleri:

- `NODE_ENV=production`
- `PUBLIC_ORIGIN=https://sitenin-alan-adi` (sonunda `/` olmadan)
- `VD_DATA_DIR=/kalici-disk/vali-diecast`
- `PORT=3000` (hosting başka port sağlarsa o değer)

Üretim modunda HTTPS adresi tanımlanmadan uygulama başlamaz. Oturum çerezleri HttpOnly, Secure ve SameSite ile korunur. Bakiye ve admin yetkileri sunucuda kontrol edilir. Sunucunun yalnızca web portunu dışarıya aç; kaynak dosyalarını ve `data` dizinini statik dosya olarak sunma.

`data` dizininin tamamını düzenli yedekle. Uygulamayı durdurarak alınan dizin yedeği hem kayıtları hem fotoğrafları içerir. Birden çok sunucu kopyası aynı SQLite dosyasını paylaşacak şekilde kurulmaz; bu paket tek uygulama süreci içindir.

## Ücretsiz hostta deneme — Render

Bu paket `render.yaml` ile Node.js kullanan ücretsiz Render Web Service denemesi için hazırlanmıştır. Dockerfile ayrıca alternatif kurulum için bulunur. **Static Site yerine Web Service seç.**

1. ZIP’i aç. Dosyalar arşivin doğrudan ana dizinindedir. İçindeki tüm dosyaları kendi GitHub deposunun köküne yükle. ZIP dosyasının kendisini yükleme. `package.json`, `package-lock.json`, `server.mjs`, `render.yaml` ve `public` klasörü depo kökünde olmalı. `data`, `.env` ve kullanıcı fotoğraflarını depoya yükleme.
2. Render hesabında **New → Blueprint** seç ve bu depoyu bağla. `render.yaml`, Node.js kullanan `free` planlı bir web servisi tanımlar.
3. Kurulum ekranında **VD_ADMIN_PASSWORD** için en az 12 karakterlik bir şifre gir. Yönetim hesabının kullanıcı ID’si `admin` olacak. Şifre kodda veya ZIP’te bulunmaz.
4. Yayın tamamlandığında Render’ın verdiği `https://…onrender.com` adresini aç. **Hesabım → giriş → admin** ile giriş yap.
5. Ürünlerin gerçek stok ve fiyatlarını ayarla. Test üyeleri kaydet; admin panelinden bakiyelerini yükle. Sipariş, hediye, fotoğraf ve ilan onayı akışlarını dene.

### Mevcut Render servisini düzeltme

Yeni ZIP içeriğini GitHub deposunun ana dizinine yükle; eski dosyaları güncelle. Render Settings bölümünde:

- Language / Runtime: **Node**
- Root Directory: **boş** (dosyalar depo kökündeyse)
- Build Command: **npm ci**
- Start Command: **npm start**
- Health Check Path: **/healthz**

Environment bölümünde `NODE_VERSION=24.19.0`, `NODE_ENV=production` ve en az 12 karakterlik `VD_ADMIN_PASSWORD` tanımla. Kaydet; Manual Deploy → Deploy latest commit seç. `yarn start`, `bundle install` ve `bundle exec puma` komutlarını kullanma.

`package.json` bulunamadı hatası alırsan GitHub deposunda bu dosyanın bulunduğu klasörü kontrol et. Dosyaların hepsi bir alt klasördeyse Root Directory o klasör adı olmalıdır. Yalnızca ZIP veya HTML yüklenmişse sunucu çalışmaz.

Render’ın otomatik `RENDER_EXTERNAL_URL` değişkeni site adresi olarak kullanılır; ilk kurulumda `PUBLIC_ORIGIN` yazman gerekmez. Kendi alan adını bağlarsan `PUBLIC_ORIGIN` değişkenini HTTPS alan adına ayarla. Servis, Render’ın verdiği `PORT` üzerinde ve `0.0.0.0` adresinde çalışır. `/healthz` kontrol adresi eklenmiştir.

**Ücretsiz denemenin veri sınırı:** Render Free kalıcı disk sağlamaz. Uykuya geçme, yeniden başlama veya yeni yayın sırasında üyeler, bakiyeler, siparişler ve yüklenen fotoğraflar silinebilir. Bu kurulumu deneme verileriyle kullan. Kalıcı kullanımda ücretli kalıcı disk veya ayrı kalıcı veritabanı ve fotoğraf depolaması gerekir. Admin şifresi ortam değişkeninde durduğu için ilk kurulum şifresiyle yeni admin hesabı yeniden oluşur.

Resmî kurulum ve sınırlar: https://render.com/docs/blueprint-spec — https://render.com/docs/free

Docker destekleyen başka bir hostta da aynı `Dockerfile` kullanılabilir. `PUBLIC_ORIGIN`, `VD_ADMIN_PASSWORD`, `PORT` ve kalıcı disk yolunu o hostun ayarlarına göre tanımla. Klasik HTML yükleme alanı tek başına sunucuyu çalıştırmaz.

## Yerelde Docker ile deneme

```bash
docker build -t vali-diecast .
docker run --rm -p 3000:3000 -e NODE_ENV=development -v vali-data:/app/data vali-diecast
```

Tarayıcıda `http://localhost:3000` açılır. İlk admin şifresi terminalde gösterilir. Yerelde Docker volume kullanıldığı için veriler sonraki çalıştırmada korunur. Bu komut yerel deneme içindir; internet yayını için HTTPS ayarlarını kullan.

## İlk yönetim işlemleri

Giriş yaptıktan sonra Hesabım → Admin paneli → Kullanıcılar bölümünden kullanıcı ara, **Bakiye yükle** seç ve açıklama gir. Ürün stokları başlangıçta sıfırdır; satılacak gerçek ürünlerin fiyat ve stoklarını yönetimden ayarla. Örnek satıcı, ilan, blog, topluluk profili ve satış kaydı yoktur. WhatsApp numarasını Ayarlar bölümünden gir. Profil pazarındaki tasarımlar hazırdır; fiyat ve görünürlükleri admin tarafından değiştirilebilir.

## Sipariş ve bakiye

- Bakiye sadece hesap sahibi ve admin tarafından görülebilir. Hesap sahibi bakiye kartına Hesabım alanından ulaşır; halka açık profilde bakiye gösterilmez.
- Sipariş verildiğinde tutar bakiyeden düşülür ve stok ayrılır.
- Onay beklerken sipariş sahibi ürün ekleyebilir, çıkarabilir ve adetleri değiştirebilir. Eski satırların birim fiyatları korunur; yeni ürünler güncel fiyatla eklenir. Tutar farkı aynı işlemde bakiyeye yansır.
- Hazırlanıyor durumuna geçince düzenleme kalıcı olarak kapanır. Durumlar sırayla ilerler.
- Admin iptalinde bakiye ve ayrılmış stok yalnızca bir kez iade edilir.
- Profil pazarı alışverişi bakiyeden karşılanır ve admin onayına gider. Reddedilirse tutar bir kez iade edilir. İlan hakkı ilk yayın onayında tüketilir.
- Kullanıcı pazarındaki takaslar ve satıcılarla görüşülen teklifler bakiye transferi yapmaz. Site dışında yürütülen teslimat anlaşmaları ayrı tutulur.

Fotoğraf seçildiğinde tarayıcı 30 MB’ye kadar kaynak fotoğrafı açar, uzun kenarı en fazla 1600 piksele küçültür ve sunucuya en fazla 800 KB JPEG gönderir. Tarayıcı HEIC dosyasını açamıyorsa JPG seçilmesini isteyen açık bir hata gösterilir. Kalıcı fotoğraf yüklemeleri sunucu sürümünde çalışır.

## Kontroller

```bash
npm test
```

Testler ayrı geçici veritabanında çalışır. İki kullanıcıyla erişim sınırları, bakiye gizliliği, sipariş düzenleme/kilitleme, stok, tekrar gönderilen işlemler, iadeler, hediyeler, profil pazarı, takip/blog bildirimleri ve yeniden başlatmada kalıcılık kontrol edilir. Arayüzün JavaScript akışları da kontrol edilir. Gerçek iPhone/Safari ve tarayıcıda görsel kontroller yapılmamıştır.

Tek HTML dosyası dosya olarak açıldığında kataloğu görüntüler. Gerçek hesap, bakiye, ilan ve sipariş işlemleri bu sunucuda çalışan web adresinden yapılır. Tarayıcıdaki eski yerel hesaplar otomatik olarak sunucu hesabına dönüştürülmez.
